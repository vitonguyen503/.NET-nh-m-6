﻿using FontAwesome.Sharp;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace H503CenterManagementSystem
{
    public class Grade
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Dob { get; set; }
        public double Midterm { get; set; }
        public double Final { get; set; }
        public double GPA { get; set; }

    }
    /// <summary>
    /// Interaction logic for Grades.xaml
    /// </summary>
    public partial class Grades : UserControl
    {
        public ObservableCollection<Grade> grades { get; set; }
        string connectString = "";
        SqlConnection con = new SqlConnection();
        public Grades()
        {
            InitializeComponent();
            try
            {
                connectString = @"Data Source=.;Initial Catalog=master;Integrated Security=True;";
                con.ConnectionString = connectString;
                con.Open();
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Error connecting to database!");
            }
            setCbboxCourse(); setDgGrade("select id,name,date_of_birth, midterm_score,final_score,average_score from Student;");
        }
        
        private void setCbboxCourse()
        {
            string query = "select course_name from Course;";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cbCourse.Items.Add(reader.GetString(0));
            }
            reader.Close();
        }

        private void setDgGrade(string query)
        {
            grades = new ObservableCollection<Grade>();
            dgGrade.ItemsSource = grades;
            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                DateTime tmp = reader.GetDateTime(2);
                string temp = tmp.ToString("yyyy-MM-dd");
                int id = reader.GetInt32(0);
                string name = reader.GetString(1);
                double mid = reader.GetDouble(3);
                double fin = reader.GetDouble(4);
                double gpa = reader.GetDouble(5);
                gpa = Double.Parse(gpa.ToString("F2"));
                
                var grade = new Grade()
                {
                    ID = id,
                    Name = name,
                    Dob = temp,
                    Midterm = mid,
                    Final = fin,
                    GPA = gpa
                };
                grades.Add(grade);
            }
            reader.Close();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string query;
            if (cbCourse.SelectedIndex == -1)
            {
                if (txtSearch.Text.Length == 0)
                {
                    query = "select id,name,date_of_birth, midterm_score,final_score,average_score from Student;";
                }
                else
                {
                    query = "select id,name,date_of_birth, midterm_score,final_score,average_score from Student where name like '" + txtSearch.Text + "%'";
                }
            }
            else
            {
                string course = cbCourse.SelectedItem.ToString();
                if (txtSearch.Text.Length == 0)
                {
                    query = "select id,name,date_of_birth, midterm_score,final_score,average_score from Student where registered_course = '" + course + "';";
                }
                else
                {
                    query = "select id,name,date_of_birth, midterm_score,final_score,average_score from Student where name like '" + txtSearch.Text + "%'"
                        + " and registered_course = '" + course + "';";
                }
            }
            setDgGrade(query);
        }

        private void dgGrade_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(dgGrade.SelectedItem != null)
            {
                Grade selectedRow = dgGrade.SelectedItem as Grade;
                txtID.Text = selectedRow.ID.ToString();
                txtName.Text = selectedRow.Name;
                txtDoB.Text = selectedRow.Dob;
                string query = "select registered_course from Student where id = " + txtID.Text;
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();
                string course = "";
                while(reader.Read()) course = reader.GetString(0);
                reader.Close();
                cbCourse.SelectedItem = course;
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            double mid, final;
            if(!Double.TryParse(txtMidterm.Text, out mid)){
                MessageBox.Show("Wrong mark format!");
                txtMidterm.Focus();
                return;
            }
            if(!Double.TryParse(txtFinal.Text, out final))
            {
                MessageBox.Show("Wrong mark format!");
                txtFinal.Focus();
                return;
            }
            if(0 > mid || 100 < mid)
            {
                MessageBox.Show("Invalid mark!");
                txtMidterm.Focus();
                return;
            }
            if(0 > final || 100 < final)
            {
                MessageBox.Show("Invalid mark!");
                txtFinal.Focus();
                return;
            }
            string query = "update Student set midterm_score = " + mid + ", final_score = " + final + " where id = " + txtID.Text + ";";
            SqlCommand command = new SqlCommand(query, con);
            command.ExecuteNonQuery();
            MessageBox.Show("Mark editted!");
            if(cbCourse.SelectedIndex == -1)
            {
                query = "select id,name,date_of_birth, midterm_score,final_score,average_score from Student;";
            }
            else
            {
                string course = cbCourse.SelectedItem.ToString();
                query = "select id,name,date_of_birth, midterm_score,final_score,average_score from Student where registered_course = '" + course + "';";
            }
            setDgGrade(query);
            txtID.Text = txtName.Text = txtDoB.Text = txtMidterm.Text = txtFinal.Text = "";
        }
    }
}
