﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.ComponentModel;

namespace H503CenterManagementSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private BackgroundWorker bgWorker = new BackgroundWorker();
        private int _state;
        public int State
        {
            get { return _state; }
            set
            {
                _state = value;
                if(PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("State"));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            // Dashboard db = new Dashboard();
            // db.Show();

            LoginPage loginpage = new LoginPage();
            bgWorker.DoWork += (s, e) =>
            {
                for (int i = 1; i <= 100; i++)
                {
                    System.Threading.Thread.Sleep(100);
                    State = i;
                }
                // Call new window and shut this window
                //MessageBox.Show("Complete loading!");
                
            };
            bgWorker.RunWorkerAsync();
            pbSplash.ValueChanged += (sender, e) =>
            {
                // Check if the progress bar's value has reached the maximum value
                if (pbSplash.Value == pbSplash.Maximum)
                {
                    // Close the splash window
                    this.Close();

                    // Open the new window
                    loginpage.Show();
                    
                }
            };


        }

        private void ProgressBar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }
    }
}
