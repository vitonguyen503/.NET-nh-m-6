﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using H503CenterManagementSystem;
using FontAwesome.Sharp;
using System.Windows.Forms.VisualStyles;
using System.Diagnostics;

namespace H503CenterManagementSystem
{
    /// <summary>
    /// Interaction logic for Student.xaml
    /// </summary


    public class Coursess
    {
        public int ID { get; set; }
        public string Title { get; set; }
        //public string Date_of_Birth { get; set; }
        public int Lessons { get; set; }
        public double Fee { get; set; }
        public string Description { get; set; }
        //public string Taught_Course { get; set; }

    }
    public partial class Courses : System.Windows.Controls.UserControl
    {

        public ObservableCollection<Coursess> course { get; set; }
        string connectorString = "";
        SqlConnection conn = new SqlConnection();
        DataTable data = null;
        public Courses()
        {
            InitializeComponent();
            try
            {
                connectorString = @"Data Source=.;Initial Catalog=master;Integrated Security=True;";
                conn.ConnectionString = connectorString;
                conn.Open();
                getData();

            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message);
            }
            setData("SELECT course_id, course_name, num_of_lessons, tuition_fee, description FROM Course;");

        }


        private void setData(string sql)
        {
            course = new ObservableCollection<Coursess>();
            datatable.ItemsSource = course;
            //string query = "SELECT id, name, date_of_birth, phone_number, address, registered_course FROM Student;";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {

                int ID = reader.GetInt32(0);
                string Title = reader.GetString(1);
                int Lessons = reader.GetInt32(2);
                double Fee = (double)reader.GetDecimal(3);
                string Description = reader.GetString(4);
                //string Taught_Course = reader.GetString(5);
                var courses = new Coursess
                {
                    ID = ID,
                    Title = Title,
                    Lessons = Lessons,
                    Fee = Fee,
                    Description = Description,

                };
                course.Add(courses);
            }
            reader.Close();
            reset();
        }
        private void getData()
        {
            datatable.ItemsSource = null;
            if (conn.State != ConnectionState.Open) return;
            else
            {
                string sql = "SELECT course_id, course_name, num_of_lessons, tuition_fee, description FROM Course;";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                DataSet dataset = new DataSet();
                adapter.Fill(dataset);
                data = dataset.Tables[0];
                datatable.ItemsSource = data.DefaultView;
            }
        }
        private void reset()
        {
            txtID.Text = txtTitle.Text = txtLessons.Text = txtFee.Text = txtDescription.Text = "";

        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string query;
            if (txtSearch.Text.Length == 0)
            {
                query = "SELECT course_id, course_name, num_of_lessons, tuition_fee, description FROM Course;";
            }
            else
            {
                query = "SELECT course_id, course_name, num_of_lessons, tuition_fee, description FROM Course where course_name like '" + txtSearch.Text + "%';";
            }
            setData(query);
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text.Length <= 0 || txtTitle.Text.Length <= 0 || txtLessons.Text.Length <= 0
                || txtFee.Text.Length <= 0 || txtDescription.Text.Length <= 0)
            {
                System.Windows.MessageBox.Show("Missing information!");
                return;
            }

            string mamh = txtID.Text;
            string ten = txtTitle.Text, buoihoc = txtLessons.Text, hocphi = txtFee.Text;
            string mota = txtDescription.Text;
            string sql = "insert into Course (course_id, course_name, num_of_lessons, tuition_fee, description, num_of_students, num_of_teachers) " +
                "values ('" + mamh + "', '" + ten + "', '" + buoihoc + "', '" + hocphi + "', '" + mota + "', 0, 0);";
            SqlCommand cmd = new SqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                System.Windows.MessageBox.Show("There's already been a teacher with that ID!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                txtID.Focus();
                return;
            }
            System.Windows.MessageBox.Show("Course added!");
            setData("SELECT course_id, course_name, num_of_lessons, tuition_fee, description FROM Course;");
            reset();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text.Length <= 0 || txtTitle.Text.Length <= 0 || txtLessons.Text.Length <= 0
                || txtFee.Text.Length <= 0 || txtDescription.Text.Length <= 0)
            {
                System.Windows.MessageBox.Show("Missing information!");
                return;
            }
            string prev_course = "";
            string query = "select course_name from Course where course_id = " + txtID.Text + ";";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read()) prev_course = reader.GetString(0);
            reader.Close();

            string mamh = txtID.Text;
            string ten = txtTitle.Text, buoihoc = txtLessons.Text, hocphi = txtFee.Text;
            string mota = txtDescription.Text;
            string sql = "update Course set course_name = '" + ten + "', num_of_lessons = '" + buoihoc
                + "', tuition_fee = '" + hocphi + "', description = '" + mota + "' WHERE course_id = '"
                + mamh + "';";
            cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();

            // Update student and teacher in the course whose name was editted
            if (!String.Equals(prev_course, ten))
            {
                query = "update Student set registered_course = '" + ten + "' where registered_course = '" + prev_course + "';";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                query = "update Teacher set taught_course = '" + ten + "' where taught_course = '" + prev_course + "';";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
            System.Windows.MessageBox.Show("Course editted!");
            setData("SELECT course_id, course_name, num_of_lessons, tuition_fee, description FROM Course;");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text.Length <= 0)
            {
                System.Windows.MessageBox.Show("Missing ID!");
            }
            else
            {
                string query = "select course_name from Course where course_id = " + txtID.Text;
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                string prev_course = "";
                while (reader.Read()) prev_course = reader.GetString(0);
                reader.Close();

                string sql = "delete from Course where course_id = '" + txtID.Text + "';";
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();

                // Delete students and teachers in the deleted course
                if (!String.Equals(prev_course, ""))
                {
                    query = "delete from Student where registered_course = '" + prev_course + "';";
                    cmd = new SqlCommand(query, conn); cmd.ExecuteNonQuery();
                    query = "delete from Teacher where taught_course = '" + prev_course + "';";
                    cmd = new SqlCommand(query, conn); cmd.ExecuteNonQuery();
                }
                System.Windows.MessageBox.Show("Course deleted!");
                setData("SELECT course_id, course_name, num_of_lessons, tuition_fee, description FROM Course;");
                reset();
            }
        }



        private void datatable_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (datatable.SelectedItem != null)
            {
                Coursess selectedRow = datatable.SelectedItem as Coursess;
                txtID.Text = selectedRow.ID.ToString();
                txtTitle.Text = selectedRow.Title;
                txtLessons.Text = selectedRow.Lessons.ToString();
                txtFee.Text = selectedRow.Fee.ToString();
                txtDescription.Text = selectedRow.Description;
            }
        }
    }
};