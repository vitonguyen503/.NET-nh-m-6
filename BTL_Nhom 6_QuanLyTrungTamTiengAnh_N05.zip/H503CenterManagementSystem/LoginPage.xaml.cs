﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace H503CenterManagementSystem
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Window
    {
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            Application.Current.Shutdown();
        }
        public LoginPage()
        {
            InitializeComponent();
        }

        private void Window_MouseDown(object sender, MouseEventArgs e)
        {
            if(e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (txtUsername.Text.Length == 0 || pbPassword.Password.Length == 0)
            {
                MessageBox.Show("Missing information!");
                return;
            }

            string connectString = "";
            SqlConnection con = new SqlConnection();
            try
            {
                connectString = @"Data Source=.;Initial Catalog=master;Integrated Security=True;";
                con.ConnectionString = connectString;
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            string user = txtUsername.Text, pass = "";
            string sqlQuery = "SELECT username FROM accounts where username = '" + user + "';";
            SqlCommand command = new SqlCommand(sqlQuery, con);

            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Close();
                sqlQuery = "SELECT password FROM accounts where username = '" + user + "';";
                command = new SqlCommand(sqlQuery, con);
                reader = command.ExecuteReader();
                if (reader.Read())
                {
                    pass = reader[0].ToString();
                }

                if (String.Equals(pass, pbPassword.Password))
                {
                    MessageBox.Show("Login successfully!");
                    Dashboard tmp = new Dashboard();
                    this.Hide();
                    tmp.Show();
                    //this.Close();
                }
                else
                {
                    MessageBox.Show("Wrong password!");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Invalid username!");
                return;
            }
        }

        private void btnChangePass_Click(object sender, RoutedEventArgs e)
        {
            ChangePass tmp = new ChangePass();
            tmp.Show();
        }

        private void txtUsername_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
