﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace H503CenterManagementSystem
{
    /// <summary>
    /// Interaction logic for ChangePass.xaml
    /// </summary>
    public partial class ChangePass : Window
    {
        public ChangePass()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if(pbOldPassword.Password.Length == 0 || pbNewPassword.Password.Length == 0 || pbConfirm.Password.Length == 0 || txtUsername.Text.Length == 0)
            {
                MessageBox.Show("Missing information!");
                return;
            }
            if(!String.Equals(pbNewPassword.Password, pbConfirm.Password))
            {
                MessageBox.Show("New password doesn't match!");
                return;
            }
            string connectString = "";
            SqlConnection con = new SqlConnection();
            try
            {
                connectString = @"Data Source=.;Initial Catalog=master;Integrated Security=True;";
                con.ConnectionString = connectString;
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            string user = txtUsername.Text, pass = pbOldPassword.Password, newPass = pbNewPassword.Password;
            string sqlQuery = "SELECT password FROM accounts where username = '" + user + "';";
            SqlCommand command = new SqlCommand(sqlQuery, con);

            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                string tmp = "";
                if (reader.Read())
                {
                    tmp = reader[0].ToString();
                }
                reader.Close();
                if(String.Equals(tmp, pass))
                {
                    sqlQuery = "UPDATE accounts SET password = @pass WHERE username = @username";
                    command = new SqlCommand(sqlQuery, con);
                    command.Parameters.AddWithValue("@pass", newPass);
                    command.Parameters.AddWithValue("@username", user);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Update successfully!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Wrong password!");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Invalid username!");
                return;
            }
        }
    }
}
