﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using H503CenterManagementSystem;
using FontAwesome.Sharp;
using System.Windows.Forms.VisualStyles;
using System.Diagnostics;

namespace H503CenterManagementSystem
{
    /// <summary>
    /// Interaction logic for Student.xaml
    /// </summary


    public class Teachers
    {
        public int ID { get; set; }
        public string Name { get; set; }
        //public string Date_of_Birth { get; set; }
        public string Address { get; set; }
        public string Number { get; set; }
        public string IELTS { get; set; }
        public string Course { get; set; }

    }
    public partial class Teacher : System.Windows.Controls.UserControl
    {

        public ObservableCollection<Teachers> teacher { get; set; }
        string connectorString = "";
        SqlConnection conn = new SqlConnection();
        DataTable data = null;
        public Teacher()
        {
            InitializeComponent();
            cbIETLS.Items.Add("7.5");
            cbIETLS.Items.Add("8.0");
            cbIETLS.Items.Add("8.5");
            cbIETLS.Items.Add("9.0");
            try
            {
                connectorString = @"Data Source=.;Initial Catalog=master;Integrated Security=True;";
                conn.ConnectionString = connectorString;
                conn.Open();
                getData();

            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message);
            }
            setData("SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher;");
            setcb();
        }
        private void setcb()
        {
            string sql = "select course_name from Course";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                cbCourse.Items.Add(reader.GetString(0));
            }
        }

        private void setData(string sql)
        {
            teacher = new ObservableCollection<Teachers>();
            datatable.ItemsSource = teacher;
            //string query = "SELECT id, name, date_of_birth, phone_number, address, registered_course FROM Student;";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {

                int ID = reader.GetInt32(0);
                string Name = reader.GetString(1);
                string Number = reader.GetString(3);
                string Address = reader.GetString(2);
                string IELTS = reader.GetString(4);
                string Course = reader.GetString(5);
                var teachers = new Teachers
                {
                    ID = ID,
                    Name = Name,
                    Number = Number,
                    Address = Address,
                    IELTS = IELTS,
                    Course = Course,
                };
                teacher.Add(teachers);
            }
            reader.Close();
            reset();
        }
        private void getData()
        {
            datatable.ItemsSource = null;
            if (conn.State != ConnectionState.Open) return;
            else
            {
                string sql = "SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher;";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                DataSet dataset = new DataSet();
                adapter.Fill(dataset);
                data = dataset.Tables[0];
                datatable.ItemsSource = data.DefaultView;
            }
        }
        private void reset()
        {
            txtID.Text = txtName.Text = txtAddress.Text = txtNumber.Text = txtSearch.Text = "";
            cbCourse.SelectedIndex = -1;
            cbIETLS.SelectedIndex = -1;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string query;
            if (cbCourse.SelectedIndex == -1 && cbIETLS.SelectedIndex == -1)
            {
                if (txtSearch.Text.Length == 0)
                {
                    query = "SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher;";
                }
                else
                {
                    query = "SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher where name like '" + txtSearch.Text + "%'";
                }
            }
            else if (cbCourse.SelectedIndex != -1 && cbIETLS.SelectedIndex == -1)
            {
                string course = cbCourse.SelectedItem.ToString();
                if (txtSearch.Text.Length == 0)
                {
                    query = "SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher where taught_course = '" + course + "';";
                }
                else
                {
                    query = "SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher where name like '" + txtSearch.Text + "%'"
                        + " and taught_course = '" + course + "';";
                }
            }
            else if(cbCourse.SelectedIndex == -1 && cbIETLS.SelectedIndex != -1)
            {
                string ielts = cbIETLS.SelectedItem.ToString();
                if (txtSearch.Text.Length == 0)
                {
                    query = "SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher where english_level = '" + ielts + "';";
                }
                else
                {
                    query = "SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher where name like '" + txtSearch.Text + "%'"
                        + " and english_level = '" + ielts + "';";
                }
            }
            else
            {
                string ielts = cbIETLS.SelectedItem.ToString(), course = cbCourse.SelectedItem.ToString();
                if (txtSearch.Text.Length == 0)
                {
                    query = "SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher where english_level = '" + ielts + "' and taught_course = '"
                        + course + "';";
                }
                else
                {
                    query = "SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher where name like '" + txtSearch.Text + "%'"
                        + " and english_level = '" + ielts + "' and taught_course = '" + course + "';";
                }
            }
            setData(query);
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text.Length <= 0 || txtName.Text.Length <= 0 || txtAddress.Text.Length <= 0
                || txtNumber.Text.Length <= 0 || cbIETLS.SelectedIndex < 0 || cbCourse.SelectedIndex < 0)
            {
                System.Windows.MessageBox.Show("Missing information!");
                return;
            }

            string magv = txtID.Text;
            string ten = txtName.Text, diachi = txtAddress.Text, sdt = txtNumber.Text;
            string khoahocday = cbCourse.SelectedItem as string;
            string ielts = cbIETLS.SelectedItem as string;
            string sql = "insert into Teacher ( id, name, address, phone_number, english_level, taught_course) values ('" + magv + "', '" + ten + "', '" + diachi + "', '" + sdt + "', '" + ielts + "', '" + khoahocday + "');";
            SqlCommand cmd = new SqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                System.Windows.MessageBox.Show("There's already been a teacher with that ID!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                txtID.Focus();
                return;
            }
            // Update num_of_teacher
            sql = "update Course set num_of_teachers = num_of_teachers + 1 where course_name = '" + khoahocday + "';";
            cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            System.Windows.MessageBox.Show("Teacher added!");
            setData("SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher;");
            reset();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text.Length <= 0 || txtName.Text.Length <= 0 || txtAddress.Text.Length <= 0
                || txtNumber.Text.Length <= 0 || cbIETLS.SelectedIndex < 0 || cbCourse.SelectedIndex < 0)
            {
                System.Windows.MessageBox.Show("Missing information!");
                return;
            }
            string prev_course = "";
            string query = "select taught_course from Teacher where id = " + txtID.Text + ";";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read()) prev_course = reader.GetString(0);
            reader.Close();

            string magv = txtID.Text;
            string ten = txtName.Text, diachi = txtAddress.Text, sdt = txtNumber.Text;
            string khoahocday = cbCourse.SelectedItem as string;
            string ielts = cbIETLS.SelectedItem as string;
            string sql = "update Teacher set name = '" + ten + "', address = '" + diachi
                + "', phone_number = '" + sdt + "', english_level = '" + ielts + "', taught_course = '" + khoahocday + "' WHERE id = '"
                + magv + "';";
            cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            // Update num_of_students
            if (!String.Equals(prev_course, khoahocday))
            {
                query = "update Course set num_of_teachers = num_of_teachers - 1 where course_name = '" + prev_course + "';";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                query = "update Course set num_of_teachers = num_of_teachers + 1 where course_name = '" + khoahocday + "';";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
            System.Windows.MessageBox.Show("Teacher editted!");
            setData("SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher;");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text.Length <= 0)
            {
                System.Windows.MessageBox.Show("Missing ID!");
            }
            else
            {
                string query = "select registered_course from Student where id = " + txtID.Text;
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                string prev_course = "";
                while (reader.Read()) prev_course = reader.GetString(0);
                reader.Close();

                string sql = "delete from Teacher where id = '" + txtID.Text + "';";
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();

                // Update num_of_teachers
                if (!String.Equals(prev_course, ""))
                {
                    query = "update Course set num_of_teachers = num_of_teachers - 1 where course_name = '" + prev_course + "';";
                    cmd = new SqlCommand(query, conn); cmd.ExecuteNonQuery();
                }
                System.Windows.MessageBox.Show("Teacher deleted!");
                setData("SELECT id, name, address, phone_number, english_level, taught_course FROM Teacher;");
                reset();
            }
        }

        private void datatable_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            if (datatable.SelectedItem != null)
            {
                Teachers selectedRow = datatable.SelectedItem as Teachers;
                txtID.Text = selectedRow.ID.ToString();
                txtName.Text = selectedRow.Name;
                txtAddress.Text = selectedRow.Address;
                txtNumber.Text = selectedRow.Number;
                cbIETLS.SelectedItem = selectedRow.IELTS;
                cbCourse.SelectedItem = selectedRow.Course;
            }
        }
    }
}