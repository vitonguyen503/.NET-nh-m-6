﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using H503CenterManagementSystem;
using FontAwesome.Sharp;
using System.Windows.Forms.VisualStyles;
using System.Diagnostics;

namespace H503CenterManagementSystem
{
    /// <summary>
    /// Interaction logic for Student.xaml
    /// </summary>

    public class Students
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Birthday { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Course { get; set; }

    }
    public partial class Student : System.Windows.Controls.UserControl
    {
        public ObservableCollection<Students> student { get; set; }
        string connectorString = "";
        SqlConnection conn = new SqlConnection();

        public Student()
        {
            InitializeComponent();
            try
            {
                connectorString = @"Data Source=.;Initial Catalog=master;Integrated Security=True;";
                conn.ConnectionString = connectorString;
                conn.Open();

            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message);
            }
            setData("SELECT id, name, date_of_birth, phone_number, address, registered_course FROM Student;");
            setcb();
        }
        private void setcb()
        {
            string sql = "select course_name from Course";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                cbCourse.Items.Add(reader.GetString(0));
            }
        }
        private void setData(string sql)
        {
            student = new ObservableCollection<Students>();
            datatable.ItemsSource = student;
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                DateTime date1 = reader.GetDateTime(2);
                string date = date1.ToString("yyyy-MM-dd");
                int ID = reader.GetInt32(0);
                string Name = reader.GetString(1);
                string Phone = reader.GetString(3);
                string Address = reader.GetString(4);
                string Registered_Course = reader.GetString(5);
                var students = new Students
                {
                    ID = ID,
                    Name = Name,
                    Birthday = date,
                    Phone = Phone,
                    Address = Address,
                    Course = Registered_Course,
                };
                student.Add(students);
            }
            reader.Close();
            reset();
        }

        private void reset()
        {
            txtID.Text = txtName.Text = txtDoB.Text = txtAddress.Text = txtNumber.Text = "";
            cbCourse.SelectedIndex = -1;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string query;
            if (cbCourse.SelectedIndex == -1)
            {
                if (txtSearch.Text.Length == 0)
                {
                    query = "select id,name,date_of_birth, phone_number, address, registered_course from Student;";
                }
                else
                {
                    query = "select id,name,date_of_birth, phone_number, address, registered_course from Student where name like '" + txtSearch.Text + "%'";
                }
            }
            else
            {
                string course = cbCourse.SelectedItem.ToString();
                if (txtSearch.Text.Length == 0)
                {
                    query = "select id,name,date_of_birth, phone_number, address, registered_course from Student where registered_course = '" + course + "';";
                }
                else
                {
                    query = "select id,name,date_of_birth, phone_number, address, registered_course from Student where name like '" + txtSearch.Text + "%'"
                        + " and registered_course = '" + course + "';";
                }
            }
            setData(query);
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text.Length == 0 || txtName.Text.Length == 0 || txtDoB.Text.Length == 0
                || txtNumber.Text.Length == 0 || txtAddress.Text.Length == 0 || cbCourse.SelectedIndex == -1)
            {
                System.Windows.MessageBox.Show("Missing information!");
                return;
            }
            string dob = txtDoB.Text;
            DateTime date;
            if (!DateTime.TryParseExact(dob, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
            {
                System.Windows.MessageBox.Show("Wrong date format! Enter YYYY-MM-DD!");
                return;
            }
            string ngaysinh = date.ToString("yyyy-MM-dd");
            string masv = txtID.Text;
            string ten = txtName.Text, diachi = txtAddress.Text, sdt = txtNumber.Text;
            string khoahocdki = cbCourse.SelectedItem as string;
            string sql = "insert into Student ( id, name, date_of_birth, phone_number, address, registered_course, midterm_score, final_score) " +
                "values ('" + masv + "', '" + ten + "', '" + ngaysinh + "', '" + sdt + "', '" + diachi + "', '" + khoahocdki + "', 0, 0);";
            SqlCommand cmd = new SqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                System.Windows.MessageBox.Show("There's already been a student with that ID!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                txtID.Focus();
                return;
            }
            
            // Update num_of_students
            sql = "update Course set num_of_students = num_of_students + 1 where course_name = '" + khoahocdki + "';";
            cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            System.Windows.MessageBox.Show("Added!");
            setData("select id,name,date_of_birth, phone_number, address, registered_course from Student;");
            reset();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text.Length <= 0 || txtName.Text.Length <= 0 || txtDoB.Text.Length <= 0
                || txtAddress.Text.Length <= 0 || txtNumber.Text.Length <= 0 || cbCourse.SelectedIndex <= 0)
            {
                System.Windows.MessageBox.Show("Missing information!");
                return;
            }
            DateTime date;
            if (!DateTime.TryParseExact(txtDoB.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
            {
                System.Windows.MessageBox.Show("Wrong date format! Enter YYYY-MM-DD!");
                return;
            }
            string prev_course = "";
            string query = "select registered_course, id from Student where id = " + txtID.Text + ";";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while(reader.Read()) prev_course = reader.GetString(0);
            reader.Close();

            string ngaysinh = date.ToString("yyyy-MM-dd");
            string masv = txtID.Text;
            string ten = txtName.Text, diachi = txtAddress.Text, sdt = txtNumber.Text;
            string khoahocdki = cbCourse.SelectedItem as string;
            string sql = "update Student set name = '" + ten + "', date_of_birth = '" + ngaysinh
                + "', phone_number = '" + sdt + "', address = '" + diachi + "', registered_course = '" + khoahocdki + "' WHERE id = '"
                + masv + "';";
            cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            // Update num_of_students
            if(!String.Equals(prev_course, khoahocdki))
            {
                query = "update Course set num_of_students = num_of_students - 1 where course_name = '" + prev_course + "';";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                query = "update Course set num_of_students = num_of_students + 1 where course_name = '" + khoahocdki + "';";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
            System.Windows.MessageBox.Show("Editted!");
            setData("select id,name,date_of_birth, phone_number, address, registered_course from Student;");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (txtID.Text.Length <= 0)
            {
                System.Windows.MessageBox.Show("Missing ID!");
            }
            else
            {
                string query = "select registered_course from Student where id = " + txtID.Text;
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                string prev_course = "";
                while (reader.Read()) prev_course = reader.GetString(0);
                reader.Close();

                string sql = "delete from Student where id = " + txtID.Text + ";";
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                // Update num_of_students
                if(!String.Equals(prev_course, ""))
                {
                    query = "update Course set num_of_students = num_of_students - 1 where course_name = '" + prev_course + "';";
                    cmd = new SqlCommand(query, conn); cmd.ExecuteNonQuery();
                }
                System.Windows.MessageBox.Show("Deleted!");
                setData("select id,name,date_of_birth, phone_number, address, registered_course from Student;");
                reset();
            }
        }

        private void datatable_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (datatable.SelectedItem != null)
            {
                Students selectedRow = datatable.SelectedItem as Students;
                txtID.Text = selectedRow.ID.ToString();
                txtName.Text = selectedRow.Name;
                txtDoB.Text = selectedRow.Birthday;
                txtNumber.Text = selectedRow.Phone;
                txtAddress.Text = selectedRow.Address;
                cbCourse.SelectedItem = selectedRow.Course;
            }
        }
    }
}