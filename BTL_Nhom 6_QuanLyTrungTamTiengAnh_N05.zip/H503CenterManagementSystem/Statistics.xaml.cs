﻿using FontAwesome.Sharp;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace H503CenterManagementSystem
{
    public class Statistic
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public double Fee { get; set; }
        public int Students { get; set; }
        public int Teachers { get; set; }
        public double Profit { get; set; }
    }
    public partial class Statistics : System.Windows.Controls.UserControl
    {
        public ObservableCollection<Statistic> statistics { get; set; }
        string connectString = "";
        SqlConnection con = new SqlConnection();
        public Statistics()
        {
            InitializeComponent();
            try
            {
                connectString = @"Data Source=.;Initial Catalog=master;Integrated Security=True;";
                con.ConnectionString = connectString;
                con.Open();
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Error connecting to database!");
                return;
            }
            setDgStatistics();
        }
        private void setDgStatistics()
        {
            statistics = new ObservableCollection<Statistic>();
            dgStatistics.ItemsSource = statistics;
            double total_profit = 0;
            string query = "select course_id, course_name, tuition_fee, num_of_students, num_of_teachers from Course;";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                string name = reader.GetString(1);
                double fee = (double) reader.GetDecimal(2);
                int stu = reader.GetInt32(3);
                int teacher = reader.GetInt32(4);
                total_profit += stu * fee;

                var statistic = new Statistic()
                {
                    ID = id,
                    Title = name,
                    Fee = fee,
                    Students = stu,
                    Teachers = teacher,
                    Profit = fee * stu
                };
                statistics.Add(statistic);
            }
            lbTotalProfit.Text = total_profit.ToString();
            reader.Close();
        }

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            var saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text files (*.txt)|*.txt";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = saveFileDialog.FileName;

                // get the collection of items in the DataGrid
                var items = statistics;

                // create a StringBuilder to build the text content
                StringBuilder sb = new StringBuilder();
                sb.Append("ID".PadRight(5, ' '));
                sb.Append("Title".PadRight(35, ' '));
                sb.Append("Fee".PadRight(7, ' '));
                sb.Append("Students".PadRight(10, ' '));
                sb.Append("Teachers".PadRight(10, ' '));
                sb.Append("Profit".PadRight(10, ' '));
                sb.AppendLine();

                // loop through the rows and columns and extract the data
                foreach (var item in items)
                {
                    sb.Append(item.ID.ToString().PadRight(5, ' '));
                    sb.Append(item.Title.ToString().PadRight(35, ' '));
                    sb.Append(item.Fee.ToString().PadRight(7, ' '));
                    sb.Append(item.Students.ToString().PadRight(10, ' '));
                    sb.Append(item.Teachers.ToString().PadRight(10, ' '));
                    sb.Append(item.Profit.ToString().PadRight(10, ' '));
                    sb.AppendLine(); // move to next row
                }
                sb.Append(("Total sales: " + lbTotalProfit.Text).PadLeft(72, ' '));
                // create a StreamWriter to write the text content to the file
                using (StreamWriter sw = new StreamWriter(fileName))
                {
                    sw.Write(sb.ToString());
                }
                System.Windows.MessageBox.Show("File written to " + fileName + "!");
            }
        }
    }
}
