﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace H503CenterManagementSystem
{
    public class Course
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public int Lessons { get; set; }
        public double Fee { get; set; }
        public int Students { get; set; }
        public string Description { get; set; }
    }
    
    public partial class Home : System.Windows.Controls.UserControl
    {
        public ObservableCollection<Course> Courses { get; set; }

        string connectString = "";
        SqlConnection con = new SqlConnection();
        public Home()
        {
            InitializeComponent();
            try
            {
                connectString = @"Data Source=.;Initial Catalog=master;Integrated Security=True;";
                con.ConnectionString = connectString;
                con.Open();
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Error connecting to database!");
            }
            settbStudents(); settbTeacher(); settbCourse(); setDgTopCourse();
        }
        private void settbStudents()
        {
            string sqlQuery = "SELECT COUNT(*) FROM Student";
            SqlCommand command = new SqlCommand(sqlQuery, con);
            int stuNum = (int)command.ExecuteScalar();
            tbStudents.Text = stuNum.ToString();
        }
        private void settbTeacher()
        {
            string sqlQuery = "SELECT COUNT(*) FROM Teacher";
            SqlCommand command = new SqlCommand(sqlQuery, con);
            int stuNum = (int)command.ExecuteScalar();
            tbTeachers.Text = stuNum.ToString();
        }
        private void settbCourse()
        {
            string sqlQuery = "SELECT COUNT(*) FROM Course";
            SqlCommand command = new SqlCommand(sqlQuery, con);
            int stuNum = (int)command.ExecuteScalar();
            tbCourses.Text = stuNum.ToString();
        }
        private void setDgTopCourse()
        {
            Courses = new ObservableCollection<Course>();
            dgTopCourse.ItemsSource = Courses;
            string query = "select top 3 course_id, course_name, num_of_lessons, tuition_fee, description, num_of_students from Course ORDER BY num_of_students DESC;";
            SqlCommand command = new SqlCommand(query, con);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                var course = new Course
                {
                    ID = reader.GetInt32(0),
                    Title = reader.GetString(1),
                    Lessons = reader.GetInt32(2),
                    Fee = (double)reader.GetDecimal(3),
                    Description = reader.GetString(4),
                    Students = reader.GetInt32(5)
                };
                Courses.Add(course);
            }
        }
    }
}
